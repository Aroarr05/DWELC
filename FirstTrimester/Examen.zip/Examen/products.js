const products = [
    { nombre: "Aloe 1", precio: 20.99, stock: 10, imagen: "/assets/img/aloevera835.jpg" },
    { nombre: "Aloe 2", precio: 15.00, stock: 13, imagen: "/assets/img/aloevera834.jpg" },
    { nombre: "Aloe 3", precio: 10.00, stock: 30, imagen: "/assets/img/aloevera829.jpg" },
    { nombre: "Aloe 4", precio: 18.50, stock: 3, imagen: "/assets/img/aloevera826.jpg" },
    { nombre: "Aloe 5", precio: 5.00, stock: 10, imagen: "/assets/img/aloevera825.jpg" },
    { nombre: "Aloe 6", precio: 4.00, stock: 20, imagen: "/assets/img/aloevera829.jpg" },
    { nombre: "Aloe 7", precio: 15.50, stock: 5, imagen: "/assets/img/aloevera826.jpg" }
    
];